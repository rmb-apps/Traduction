# Traduction

Translation app for 100+ languages (Flutter). Package: `com.rmb.traduction`.

## Features
- Text translation between 100+ languages, with automatic language detection
- Voice translation: speak into the big microphone, the translation is read aloud
- Conversation mode: two people speak in turn, each in their language, with spoken translation
- Camera translation: take a photo or pick one, the text is read and translated
  (works for Latin-script languages: French, English, Spanish, Dutch...)
- Swap languages, copy, paste
- History and saved translations on the phone
- Interface in Arabic, English and French

Translations come from the free MyMemory API (no key needed).

## Build the APK with GitHub (no PC needed)
1. Create a new repository on GitHub (e.g. `traduction`).
2. Upload all the files of this folder (keep the `.github` folder).
3. Open the **Actions** tab → **Build Traduction APK** → wait until it is green.
4. Download **traduction-apk** at the bottom of the run page, unzip it, install `app-release.apk`.

## Build on a PC
```
flutter create --org com.rmb --project-name traduction --platforms android .
python3 tool/patch_android.py
flutter pub get
dart run flutter_launcher_icons
flutter build apk --release
```
