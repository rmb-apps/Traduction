import 'dart:async';
import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:image_picker/image_picker.dart';

import 'languages.dart';
import 'strings.dart';
import 'translator.dart';

class _Block {
  final Rect rect;
  final String text;
  _Block(this.rect, this.text);
}

/// Live camera translation: the translated text is drawn on top of the
/// original text, directly on the camera image (or on a photo).
class CameraTranslatePage extends StatefulWidget {
  final String uiLang, from, to;
  const CameraTranslatePage({super.key, required this.uiLang, required this.from, required this.to});
  @override
  State<CameraTranslatePage> createState() => _CameraTranslatePageState();
}

class _CameraTranslatePageState extends State<CameraTranslatePage> {
  final translator = Translator();
  final recognizer = TextRecognizer(script: TextRecognitionScript.latin);
  CameraController? ctrl;
  bool _busy = false;
  DateTime _last = DateTime.fromMillisecondsSinceEpoch(0);
  Size? src; // size of the image the text boxes refer to (upright)
  List<_Block> blocks = [];
  final Map<String, String> cache = {};
  final Set<String> pending = {};
  File? still; // frozen photo (taken or picked)
  Size? stillSize;
  String? error;
  bool working = false;

  String t(String k) => tr(widget.uiLang, k);

  @override
  void initState() {
    super.initState();
    SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
    _initCamera();
  }

  @override
  void dispose() {
    final c = ctrl;
    ctrl = null;
    if (c != null) {
      if (c.value.isStreamingImages) c.stopImageStream().catchError((_) {});
      c.dispose();
    }
    recognizer.close();
    SystemChrome.setPreferredOrientations(DeviceOrientation.values);
    super.dispose();
  }

  Future<void> _initCamera() async {
    try {
      final cams = await availableCameras();
      final back = cams.firstWhere((c) => c.lensDirection == CameraLensDirection.back,
          orElse: () => cams.first);
      final c = CameraController(
        back,
        ResolutionPreset.high,
        enableAudio: false,
        imageFormatGroup: Platform.isAndroid ? ImageFormatGroup.nv21 : ImageFormatGroup.bgra8888,
      );
      await c.initialize();
      if (!mounted) {
        c.dispose();
        return;
      }
      ctrl = c;
      setState(() {});
      await c.startImageStream(_onFrame);
    } catch (e) {
      if (mounted) setState(() => error = 'Camera: $e');
    }
  }

  // ---------- Live frames ----------

  Future<void> _onFrame(CameraImage img) async {
    if (_busy || still != null || ctrl == null) return;
    final now = DateTime.now();
    if (now.difference(_last).inMilliseconds < 1200) return;
    _busy = true;
    _last = now;
    try {
      final rot = ctrl!.description.sensorOrientation;
      final input = _toInputImage(img, rot);
      final res = await recognizer.processImage(input);
      final upright = (rot == 90 || rot == 270)
          ? Size(img.height.toDouble(), img.width.toDouble())
          : Size(img.width.toDouble(), img.height.toDouble());
      if (mounted && still == null) _update(res, upright);
    } catch (_) {
      // ignore a bad frame
    } finally {
      _busy = false;
    }
  }

  InputImage _toInputImage(CameraImage img, int rotation) {
    final single = img.planes.length == 1;
    final bytes = single ? img.planes.first.bytes : _yuv420ToNv21(img);
    return InputImage.fromBytes(
      bytes: bytes,
      metadata: InputImageMetadata(
        size: Size(img.width.toDouble(), img.height.toDouble()),
        rotation: InputImageRotationValue.fromRawValue(rotation) ?? InputImageRotation.rotation0deg,
        format: Platform.isAndroid ? InputImageFormat.nv21 : InputImageFormat.bgra8888,
        bytesPerRow: single ? img.planes.first.bytesPerRow : img.width,
      ),
    );
  }

  /// Converts a 3-plane YUV_420_888 frame to NV21 (Y then interleaved VU).
  Uint8List _yuv420ToNv21(CameraImage img) {
    final w = img.width, h = img.height;
    final out = Uint8List(w * h + 2 * (w ~/ 2) * (h ~/ 2));
    final y = img.planes[0], u = img.planes[1], v = img.planes[2];
    var i = 0;
    for (var row = 0; row < h; row++) {
      out.setRange(i, i + w, y.bytes, row * y.bytesPerRow);
      i += w;
    }
    final uvRow = u.bytesPerRow, uvPix = u.bytesPerPixel ?? 1;
    for (var row = 0; row < h ~/ 2; row++) {
      for (var col = 0; col < w ~/ 2; col++) {
        final k = row * uvRow + col * uvPix;
        out[i++] = v.bytes[k];
        out[i++] = u.bytes[k];
      }
    }
    return out;
  }

  // ---------- Text blocks & translation ----------

  void _update(RecognizedText res, Size size) {
    final list = <_Block>[];
    for (final b in res.blocks) {
      final txt = b.text.replaceAll('\n', ' ').trim();
      if (txt.length > 1) list.add(_Block(b.boundingBox, txt));
    }
    setState(() {
      src = size;
      blocks = list;
    });
    for (final b in list) {
      if (!cache.containsKey(b.text) && !pending.contains(b.text) && pending.length < 8) {
        _translate(b.text);
      }
    }
  }

  Future<void> _translate(String text) async {
    pending.add(text);
    try {
      final out = await translator.translate(text, widget.from, widget.to);
      cache[text] = out;
      error = null;
    } on TranslateException catch (e) {
      error = t(e.message);
    } finally {
      pending.remove(text);
      if (mounted) setState(() {});
    }
  }

  // ---------- Photo (shutter or gallery) ----------

  Future<void> _freeze() async {
    final c = ctrl;
    if (c == null || working) return;
    setState(() => working = true);
    try {
      if (c.value.isStreamingImages) await c.stopImageStream();
      final shot = await c.takePicture();
      await _processStill(File(shot.path));
    } catch (e) {
      setState(() => error = 'Camera: $e');
    } finally {
      if (mounted) setState(() => working = false);
    }
  }

  Future<void> _gallery() async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 2000);
    if (x == null) return;
    setState(() => working = true);
    try {
      final c = ctrl;
      if (c != null && c.value.isStreamingImages) await c.stopImageStream();
      await _processStill(File(x.path));
    } catch (e) {
      setState(() => error = 'OCR: $e');
    } finally {
      if (mounted) setState(() => working = false);
    }
  }

  Future<void> _processStill(File f) async {
    final codec = await ui.instantiateImageCodec(await f.readAsBytes());
    final frame = await codec.getNextFrame();
    final size = Size(frame.image.width.toDouble(), frame.image.height.toDouble());
    final res = await recognizer.processImage(InputImage.fromFilePath(f.path));
    setState(() {
      still = f;
      stillSize = size;
    });
    _update(res, size);
    if (blocks.isEmpty) _toast(t('noText'));
  }

  Future<void> _backToLive() async {
    setState(() {
      still = null;
      stillSize = null;
      blocks = [];
    });
    final c = ctrl;
    if (c != null && !c.value.isStreamingImages) await c.startImageStream(_onFrame);
  }

  void _copyAll() {
    final all = blocks.map((b) => cache[b.text]).whereType<String>().join('\n');
    if (all.isEmpty) return;
    Clipboard.setData(ClipboardData(text: all));
    _toast(t('copied'));
  }

  void _toast(String m) => ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(m), behavior: SnackBarBehavior.floating));

  String _name(String code) {
    if (code == 'auto') return t('detect');
    final l = langByCode(code);
    return widget.uiLang == 'en' ? l.name : l.native;
  }

  // ---------- UI ----------

  Widget _overlay() => CustomPaint(
        painter: _OverlayPainter(blocks, cache, src ?? const Size(1, 1), isRtl(widget.to)),
      );

  Widget _view() {
    if (still != null && stillSize != null) {
      return Center(
        child: FittedBox(
          fit: BoxFit.contain,
          child: SizedBox(
            width: stillSize!.width,
            height: stillSize!.height,
            child: Stack(fit: StackFit.expand, children: [
              Image.file(still!, fit: BoxFit.fill),
              _overlay(),
            ]),
          ),
        ),
      );
    }
    final c = ctrl;
    if (c == null || !c.value.isInitialized) {
      return Center(
        child: error != null
            ? Padding(
                padding: const EdgeInsets.all(24),
                child: Text(error!, style: const TextStyle(color: Colors.white)),
              )
            : const CircularProgressIndicator(color: Colors.white),
      );
    }
    final ps = c.value.previewSize ?? const Size(1280, 720);
    // previewSize is landscape; the screen is portrait.
    final w = ps.height, h = ps.width;
    return SizedBox.expand(
      child: FittedBox(
        fit: BoxFit.cover,
        child: SizedBox(
          width: w,
          height: h,
          child: Stack(fit: StackFit.expand, children: [
            CameraPreview(c),
            _overlay(),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(children: [
        Positioned.fill(child: _view()),
        // Top bar
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(8),
            child: Row(children: [
              IconButton.filledTonal(
                icon: const Icon(Icons.close),
                onPressed: () => Navigator.pop(context),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                decoration: BoxDecoration(
                  color: Colors.black54,
                  borderRadius: BorderRadius.circular(24),
                ),
                child: Text('${_name(widget.from)}  →  ${_name(widget.to)}',
                    style: const TextStyle(color: Colors.white, fontSize: 15)),
              ),
              const Spacer(),
              IconButton.filledTonal(icon: const Icon(Icons.copy), onPressed: _copyAll),
            ]),
          ),
        ),
        // Hint / error
        Positioned(
          left: 16,
          right: 16,
          bottom: 150,
          child: Center(
            child: (error != null || (blocks.isEmpty && still == null))
                ? Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                    decoration: BoxDecoration(
                      color: Colors.black54,
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Text(error ?? t('pointCamera'),
                        textAlign: TextAlign.center,
                        style: const TextStyle(color: Colors.white)),
                  )
                : const SizedBox.shrink(),
          ),
        ),
        // Bottom controls
        Positioned(
          left: 0,
          right: 0,
          bottom: 0,
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(30, 10, 30, 24),
              child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                _round(Icons.photo_library_outlined, _gallery),
                GestureDetector(
                  onTap: still == null ? _freeze : _backToLive,
                  child: Container(
                    width: 84,
                    height: 84,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white,
                      border: Border.all(color: Colors.white54, width: 6),
                    ),
                    child: working
                        ? const Padding(
                            padding: EdgeInsets.all(24),
                            child: CircularProgressIndicator(strokeWidth: 3),
                          )
                        : Icon(still == null ? Icons.camera_alt : Icons.refresh,
                            size: 36, color: const Color(0xFF3D7BEC)),
                  ),
                ),
                const SizedBox(width: 56),
              ]),
            ),
          ),
        ),
      ]),
    );
  }

  Widget _round(IconData icon, VoidCallback onTap) => Material(
        color: Colors.black54,
        shape: const CircleBorder(),
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Icon(icon, color: Colors.white, size: 28),
          ),
        ),
      );
}

/// Draws each translation in a white box over the original text.
class _OverlayPainter extends CustomPainter {
  final List<_Block> blocks;
  final Map<String, String> cache;
  final Size src;
  final bool rtl;
  _OverlayPainter(this.blocks, this.cache, this.src, this.rtl);

  @override
  void paint(Canvas canvas, Size size) {
    final sx = size.width / src.width, sy = size.height / src.height;
    final fill = Paint()..color = Colors.white.withOpacity(0.94);
    final outline = Paint()
      ..color = Colors.white70
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;
    for (final b in blocks) {
      var r = Rect.fromLTRB(b.rect.left * sx, b.rect.top * sy, b.rect.right * sx, b.rect.bottom * sy)
          .inflate(3);
      final translated = cache[b.text];
      if (translated == null) {
        canvas.drawRRect(RRect.fromRectAndRadius(r, const Radius.circular(6)), outline);
        continue;
      }
      double fs = (r.height * 0.75).clamp(9.0, 48.0);
      late TextPainter tp;
      while (true) {
        tp = TextPainter(
          text: TextSpan(
            text: translated,
            style: TextStyle(color: const Color(0xFF1B1F24), fontSize: fs, fontWeight: FontWeight.w600, height: 1.15),
          ),
          textDirection: rtl ? TextDirection.rtl : TextDirection.ltr,
        )..layout(maxWidth: (r.width - 8).clamp(20.0, double.infinity));
        if (tp.height <= r.height - 4 || fs <= 9) break;
        fs -= 1;
      }
      if (tp.height > r.height - 4) r = Rect.fromLTWH(r.left, r.top, r.width, tp.height + 6);
      canvas.drawRRect(RRect.fromRectAndRadius(r, const Radius.circular(6)), fill);
      final dx = rtl ? r.right - 4 - tp.width : r.left + 4;
      tp.paint(canvas, Offset(dx, r.top + (r.height - tp.height) / 2));
    }
  }

  @override
  bool shouldRepaint(covariant _OverlayPainter old) => true;
}
