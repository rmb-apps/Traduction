import 'dart:async';
import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:image_picker/image_picker.dart';

import 'languages.dart';
import 'strings.dart';
import 'translator.dart';

class _Block {
  final Rect rect;
  final String text;
  Color? bg; // background color sampled from the photo
  _Block(this.rect, this.text);
}

/// Live camera translation: the translated text is drawn on top of the
/// original text, directly on the camera image (or on a photo).
class CameraTranslatePage extends StatefulWidget {
  final String uiLang, from, to;
  const CameraTranslatePage({super.key, required this.uiLang, required this.from, required this.to});
  @override
  State<CameraTranslatePage> createState() => _CameraTranslatePageState();
}

class _CameraTranslatePageState extends State<CameraTranslatePage> {
  final translator = Translator();
  final recognizer = TextRecognizer(script: TextRecognitionScript.latin);
  CameraController? ctrl;
  bool _busy = false;
  DateTime _last = DateTime.fromMillisecondsSinceEpoch(0);
  Size? src; // size of the image the text boxes refer to (upright)
  List<_Block> blocks = [];
  final Map<String, String> cache = {};
  final Set<String> pending = {};
  File? still; // frozen photo (taken or picked)
  Size? stillSize;
  String? error;
  bool working = false;
  bool showTranslated = true; // "Original" / "Translated" switch
  ByteData? _pixels;
  int _pixelsW = 0, _pixelsH = 0;
  bool liveMode = true; // true: translate live on the camera; false: only on photo

  String t(String k) => tr(widget.uiLang, k);

  @override
  void initState() {
    super.initState();
    SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
    _initCamera();
  }

  @override
  void dispose() {
    final c = ctrl;
    ctrl = null;
    if (c != null) {
      if (c.value.isStreamingImages) c.stopImageStream().catchError((_) {});
      c.dispose();
    }
    recognizer.close();
    SystemChrome.setPreferredOrientations(DeviceOrientation.values);
    super.dispose();
  }

  Future<void> _initCamera() async {
    try {
      final cams = await availableCameras();
      final back = cams.firstWhere((c) => c.lensDirection == CameraLensDirection.back,
          orElse: () => cams.first);
      final c = CameraController(
        back,
        ResolutionPreset.high,
        enableAudio: false,
        imageFormatGroup: Platform.isAndroid ? ImageFormatGroup.nv21 : ImageFormatGroup.bgra8888,
      );
      await c.initialize();
      if (!mounted) {
        c.dispose();
        return;
      }
      ctrl = c;
      setState(() {});
      await c.startImageStream(_onFrame);
    } catch (e) {
      if (mounted) setState(() => error = 'Camera: $e');
    }
  }

  // ---------- Live frames ----------

  Future<void> _onFrame(CameraImage img) async {
    if (_busy || still != null || ctrl == null) return;
    final now = DateTime.now();
    if (now.difference(_last).inMilliseconds < 1200) return;
    _busy = true;
    _last = now;
    try {
      final rot = ctrl!.description.sensorOrientation;
      final input = _toInputImage(img, rot);
      final res = await recognizer.processImage(input);
      final upright = (rot == 90 || rot == 270)
          ? Size(img.height.toDouble(), img.width.toDouble())
          : Size(img.width.toDouble(), img.height.toDouble());
      if (mounted && still == null) _update(res, upright);
    } catch (_) {
      // ignore a bad frame
    } finally {
      _busy = false;
    }
  }

  InputImage _toInputImage(CameraImage img, int rotation) {
    final single = img.planes.length == 1;
    final bytes = single ? img.planes.first.bytes : _yuv420ToNv21(img);
    return InputImage.fromBytes(
      bytes: bytes,
      metadata: InputImageMetadata(
        size: Size(img.width.toDouble(), img.height.toDouble()),
        rotation: InputImageRotationValue.fromRawValue(rotation) ?? InputImageRotation.rotation0deg,
        format: Platform.isAndroid ? InputImageFormat.nv21 : InputImageFormat.bgra8888,
        bytesPerRow: single ? img.planes.first.bytesPerRow : img.width,
      ),
    );
  }

  /// Converts a 3-plane YUV_420_888 frame to NV21 (Y then interleaved VU).
  Uint8List _yuv420ToNv21(CameraImage img) {
    final w = img.width, h = img.height;
    final out = Uint8List(w * h + 2 * (w ~/ 2) * (h ~/ 2));
    final y = img.planes[0], u = img.planes[1], v = img.planes[2];
    var i = 0;
    for (var row = 0; row < h; row++) {
      out.setRange(i, i + w, y.bytes, row * y.bytesPerRow);
      i += w;
    }
    final uvRow = u.bytesPerRow, uvPix = u.bytesPerPixel ?? 1;
    for (var row = 0; row < h ~/ 2; row++) {
      for (var col = 0; col < w ~/ 2; col++) {
        final k = row * uvRow + col * uvPix;
        out[i++] = v.bytes[k];
        out[i++] = u.bytes[k];
      }
    }
    return out;
  }

  // ---------- Text blocks & translation ----------

  void _update(RecognizedText res, Size size) {
    final list = <_Block>[];
    for (final b in res.blocks) {
      final txt = b.text.replaceAll('\n', ' ').trim();
      if (txt.length > 1) list.add(_Block(b.boundingBox, txt));
    }
    setState(() {
      src = size;
      blocks = list;
    });
    // Live view only shows where the text is; the translation is done
    // when a photo is taken (or picked), for all the text at once.
    if (still != null) {
      _translateAll(list);
    } else if (liveMode) {
      for (final b in list) {
        if (!cache.containsKey(b.text) && !pending.contains(b.text) && pending.length < 6) {
          _translate(b.text);
        }
      }
    }
  }

  Future<void> _translateAll(List<_Block> list) async {
    final todo = list.map((b) => b.text).where((x) => !cache.containsKey(x)).toSet().toList();
    var next = 0;
    Future<void> worker() async {
      while (next < todo.length && mounted) {
        final text = todo[next++];
        await _translate(text);
      }
    }
    await Future.wait(List.generate(4, (_) => worker()));
  }

  Future<void> _translate(String text) async {
    pending.add(text);
    try {
      final out = await translator.translate(text, widget.from, widget.to);
      cache[text] = out;
      error = null;
    } on TranslateException catch (e) {
      error = t(e.message);
    } finally {
      pending.remove(text);
      if (mounted) setState(() {});
    }
  }

  // ---------- Photo (shutter or gallery) ----------

  Future<void> _freeze() async {
    final c = ctrl;
    if (c == null || working) return;
    setState(() => working = true);
    try {
      if (c.value.isStreamingImages) await c.stopImageStream();
      final shot = await c.takePicture();
      await _processStill(File(shot.path));
    } catch (e) {
      setState(() => error = 'Camera: $e');
    } finally {
      if (mounted) setState(() => working = false);
    }
  }

  Future<void> _gallery() async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 2000);
    if (x == null) return;
    setState(() => working = true);
    try {
      final c = ctrl;
      if (c != null && c.value.isStreamingImages) await c.stopImageStream();
      await _processStill(File(x.path));
    } catch (e) {
      setState(() => error = 'OCR: $e');
    } finally {
      if (mounted) setState(() => working = false);
    }
  }

  Future<void> _processStill(File f) async {
    final codec = await ui.instantiateImageCodec(await f.readAsBytes());
    final frame = await codec.getNextFrame();
    final size = Size(frame.image.width.toDouble(), frame.image.height.toDouble());
    _pixels = await frame.image.toByteData(format: ui.ImageByteFormat.rawRgba);
    _pixelsW = frame.image.width;
    _pixelsH = frame.image.height;
    final res = await recognizer.processImage(InputImage.fromFilePath(f.path));
    setState(() {
      still = f;
      stillSize = size;
      showTranslated = true;
    });
    _update(res, size);
    for (final b in blocks) {
      b.bg = _sampleColor(b.rect);
    }
    if (blocks.isEmpty) _toast(t('noText'));
  }

  /// Average color of the photo around a text box (its background).
  Color? _sampleColor(Rect r) {
    final px = _pixels;
    if (px == null) return null;
    int rs = 0, gs = 0, bs = 0, n = 0;
    void add(double x, double y) {
      final xi = x.round().clamp(0, _pixelsW - 1), yi = y.round().clamp(0, _pixelsH - 1);
      final i = (yi * _pixelsW + xi) * 4;
      rs += px.getUint8(i);
      gs += px.getUint8(i + 1);
      bs += px.getUint8(i + 2);
      n++;
    }
    final box = r.inflate(4);
    for (var k = 0; k <= 20; k++) {
      final x = box.left + box.width * k / 20;
      add(x, box.top);
      add(x, box.bottom);
    }
    for (var k = 0; k <= 8; k++) {
      final y = box.top + box.height * k / 8;
      add(box.left, y);
      add(box.right, y);
    }
    if (n == 0) return null;
    return Color.fromARGB(255, rs ~/ n, gs ~/ n, bs ~/ n);
  }

  Future<void> _backToLive() async {
    setState(() {
      still = null;
      stillSize = null;
      blocks = [];
      _pixels = null;
    });
    final c = ctrl;
    if (c != null && !c.value.isStreamingImages) await c.startImageStream(_onFrame);
  }

  void _copyAll() {
    final all = blocks.map((b) => cache[b.text]).whereType<String>().join('\n');
    if (all.isEmpty) return;
    Clipboard.setData(ClipboardData(text: all));
    _toast(t('copied'));
  }

  void _toast(String m) => ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(m), behavior: SnackBarBehavior.floating));

  String _name(String code) {
    if (code == 'auto') return t('detect');
    final l = langByCode(code);
    return widget.uiLang == 'en' ? l.name : l.native;
  }

  // ---------- UI ----------

  Widget _overlay() => !showTranslated
      ? const SizedBox.expand()
      : CustomPaint(
        painter: _OverlayPainter(blocks, cache, src ?? const Size(1, 1), isRtl(widget.to)),
      );

  Widget _view() {
    if (still != null && stillSize != null) {
      return Center(
        child: FittedBox(
          fit: BoxFit.contain,
          child: SizedBox(
            width: stillSize!.width,
            height: stillSize!.height,
            child: Stack(fit: StackFit.expand, children: [
              Image.file(still!, fit: BoxFit.fill),
              _overlay(),
            ]),
          ),
        ),
      );
    }
    final c = ctrl;
    if (c == null || !c.value.isInitialized) {
      return Center(
        child: error != null
            ? Padding(
                padding: const EdgeInsets.all(24),
                child: Text(error!, style: const TextStyle(color: Colors.white)),
              )
            : const CircularProgressIndicator(color: Colors.white),
      );
    }
    final ps = c.value.previewSize ?? const Size(1280, 720);
    // previewSize is landscape; the screen is portrait.
    final w = ps.height, h = ps.width;
    return SizedBox.expand(
      child: FittedBox(
        fit: BoxFit.cover,
        child: SizedBox(
          width: w,
          height: h,
          child: Stack(fit: StackFit.expand, children: [
            CameraPreview(c),
            _overlay(),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SizedBox.expand(
        child: Stack(children: [
        Positioned.fill(child: _view()),
        // Top bar
        Positioned(
          top: 0,
          left: 0,
          right: 0,
          child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(8),
            child: Row(children: [
              IconButton.filledTonal(
                icon: const Icon(Icons.close),
                onPressed: () => Navigator.pop(context),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                decoration: BoxDecoration(
                  color: Colors.black54,
                  borderRadius: BorderRadius.circular(24),
                ),
                child: Text('${_name(widget.from)}  →  ${_name(widget.to)}',
                    style: const TextStyle(color: Colors.white, fontSize: 15)),
              ),
              const Spacer(),
              IconButton.filledTonal(icon: const Icon(Icons.copy), onPressed: _copyAll),
            ]),
          ),
        ),
        ),
        // Original / Translated switch
        Positioned(
          top: MediaQuery.of(context).padding.top + 70,
          left: 0,
          right: 0,
          child: Center(
            child: Container(
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(
                color: const Color(0xFFF5F8FD),
                borderRadius: BorderRadius.circular(30),
              ),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                _seg(t('original'), !showTranslated, () => setState(() => showTranslated = false)),
                _seg(t('translated'), showTranslated, () => setState(() => showTranslated = true)),
              ]),
            ),
          ),
        ),
        // Hint / error
        Positioned(
          left: 16,
          right: 16,
          bottom: 150,
          child: Center(
            child: (error != null || (blocks.isEmpty && still == null))
                ? Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                    decoration: BoxDecoration(
                      color: Colors.black54,
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Text(error ?? t(liveMode ? 'pointLive' : 'pointCamera'),
                        textAlign: TextAlign.center,
                        style: const TextStyle(color: Colors.white)),
                  )
                : const SizedBox.shrink(),
          ),
        ),
        // Bottom controls
        Positioned(
          left: 0,
          right: 0,
          bottom: 0,
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(30, 10, 30, 24),
              child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                _round(Icons.photo_library_outlined, _gallery),
                GestureDetector(
                  onTap: still == null ? _freeze : _backToLive,
                  child: Container(
                    width: 84,
                    height: 84,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white,
                      border: Border.all(color: Colors.white54, width: 6),
                    ),
                    child: working
                        ? const Padding(
                            padding: EdgeInsets.all(24),
                            child: CircularProgressIndicator(strokeWidth: 3),
                          )
                        : Icon(still == null ? Icons.camera_alt : Icons.refresh,
                            size: 36, color: const Color(0xFF3D7BEC)),
                  ),
                ),
                GestureDetector(
                  onTap: () => setState(() => liveMode = !liveMode),
                  child: Container(
                    width: 72,
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    decoration: BoxDecoration(
                      color: liveMode ? const Color(0xFF3D7BEC) : Colors.black54,
                      borderRadius: BorderRadius.circular(18),
                    ),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      Icon(liveMode ? Icons.translate : Icons.photo_camera_outlined,
                          color: Colors.white, size: 24),
                      const SizedBox(height: 2),
                      Text(t(liveMode ? 'modeLive' : 'modePhoto'),
                          style: const TextStyle(color: Colors.white, fontSize: 11)),
                    ]),
                  ),
                ),
              ]),
            ),
          ),
        ),
      ]),
      ),
    );
  }

  Widget _seg(String label, bool selected, VoidCallback onTap) => GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 9),
          decoration: BoxDecoration(
            color: selected ? const Color(0xFFD3E3FD) : Colors.transparent,
            borderRadius: BorderRadius.circular(26),
          ),
          child: Text(label, style: const TextStyle(fontSize: 15, color: Color(0xFF1B1F24))),
        ),
      );

  Widget _round(IconData icon, VoidCallback onTap) => Material(
        color: Colors.black54,
        shape: const CircleBorder(),
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Icon(icon, color: Colors.white, size: 28),
          ),
        ),
      );
}

/// Draws each translation over the original text, on a background that
/// matches the photo (like Google Lens). Nothing is drawn until a block
/// is translated, so there are no empty boxes.
class _OverlayPainter extends CustomPainter {
  final List<_Block> blocks;
  final Map<String, String> cache;
  final Size src;
  final bool rtl;
  _OverlayPainter(this.blocks, this.cache, this.src, this.rtl);

  @override
  void paint(Canvas canvas, Size size) {
    final sx = size.width / src.width, sy = size.height / src.height;
    for (final b in blocks) {
      final translated = cache[b.text];
      if (translated == null) continue;
      var r = Rect.fromLTRB(b.rect.left * sx, b.rect.top * sy, b.rect.right * sx, b.rect.bottom * sy)
          .inflate(2);
      final bg = b.bg ?? const Color(0xFFE8EAED);
      final textColor = bg.computeLuminance() > 0.45 ? const Color(0xFF1B1F24) : Colors.white;
      double fs = (r.height * 0.8).clamp(8.0, 60.0);
      late TextPainter tp;
      while (true) {
        tp = TextPainter(
          text: TextSpan(
            text: translated,
            style: TextStyle(color: textColor, fontSize: fs, height: 1.12),
          ),
          textDirection: rtl ? TextDirection.rtl : TextDirection.ltr,
        )..layout(maxWidth: (r.width - 4).clamp(16.0, double.infinity));
        if (tp.height <= r.height || fs <= 8) break;
        fs -= 0.5;
      }
      if (tp.height > r.height) r = Rect.fromLTWH(r.left, r.top, r.width, tp.height + 4);
      canvas.drawRRect(
        RRect.fromRectAndRadius(r, const Radius.circular(4)),
        Paint()..color = bg.withOpacity(b.bg == null ? 0.92 : 0.97),
      );
      final dx = rtl ? r.right - 2 - tp.width : r.left + 2;
      tp.paint(canvas, Offset(dx, r.top + (r.height - tp.height) / 2));
    }
  }

  @override
  bool shouldRepaint(covariant _OverlayPainter old) => true;
}
