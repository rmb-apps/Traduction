import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_recognition_result.dart';
import 'package:speech_to_text/speech_to_text.dart';

import 'languages.dart';
import 'main.dart' show LanguagePicker;
import 'strings.dart';
import 'translator.dart';

class _Msg {
  final String text, translated;
  final bool sideA;
  _Msg(this.text, this.translated, this.sideA);
}

/// Voice conversation: two people speak in turn, each in their own
/// language; every sentence is translated and read aloud for the other.
class ConversationPage extends StatefulWidget {
  final String uiLang;
  final String langA, langB;
  final List<String> recent;
  const ConversationPage(
      {super.key, required this.uiLang, required this.langA, required this.langB, required this.recent});
  @override
  State<ConversationPage> createState() => _ConversationPageState();
}

class _ConversationPageState extends State<ConversationPage> {
  static const Color kBlue = Color(0xFF3D7BEC);
  static const Color kGrey = Color(0xFF46505C);

  final speech = SpeechToText();
  final tts = FlutterTts();
  final translator = Translator();
  late String a, b;
  final List<_Msg> msgs = [];
  int listening = 0; // 0 none, 1 = A, 2 = B
  String partial = '';
  bool busy = false;
  bool _handled = false;

  String t(String k) => tr(widget.uiLang, k);

  @override
  void initState() {
    super.initState();
    a = widget.langA == 'auto' ? (widget.langB == 'ar' ? 'fr' : 'ar') : widget.langA;
    b = widget.langB;
  }

  @override
  void dispose() {
    speech.stop();
    tts.stop();
    super.dispose();
  }

  String _name(String code) {
    final l = langByCode(code);
    return widget.uiLang == 'en' ? l.name : l.native;
  }

  Future<void> _listen(bool sideA) async {
    if (listening != 0) {
      final side = listening == 1;
      await speech.stop();
      // Fallback if no final result arrives after stopping.
      Future.delayed(const Duration(milliseconds: 1500), () {
        if (mounted && listening != 0 && !_handled) {
          setState(() => listening = 0);
          if (partial.trim().isNotEmpty) _process(partial, side);
        }
      });
      return;
    }
    await tts.stop();
    final ok = await speech.initialize(
      onError: (_) {
        if (mounted) setState(() => listening = 0);
      },
      onStatus: (s) {
        if ((s == 'done' || s == 'notListening') && mounted && listening != 0 && !_handled) {
          // Stopped without a final result: use what we heard.
          final side = listening == 1;
          setState(() => listening = 0);
          if (partial.trim().isNotEmpty) _process(partial, side);
        }
      },
    );
    if (!ok) {
      _toast(t('noMic'));
      return;
    }
    _handled = false;
    setState(() {
      listening = sideA ? 1 : 2;
      partial = '';
    });
    await speech.listen(
      localeId: (sideA ? a : b).replaceAll('-', '_'),
      onResult: (SpeechRecognitionResult r) {
        setState(() => partial = r.recognizedWords);
        if (r.finalResult && !_handled) {
          setState(() => listening = 0);
          _process(r.recognizedWords, sideA);
        }
      },
    );
  }

  Future<void> _process(String text, bool sideA) async {
    _handled = true;
    text = text.trim();
    if (text.isEmpty) return;
    final from = sideA ? a : b, to = sideA ? b : a;
    setState(() => busy = true);
    try {
      final out = await translator.translate(text, from, to);
      if (!mounted) return;
      setState(() {
        msgs.insert(0, _Msg(text, out, sideA));
        partial = '';
      });
      await tts.setLanguage(to);
      await tts.speak(out);
    } on TranslateException catch (e) {
      _toast(t(e.message));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _pick(bool sideA) async {
    final picked = await showModalBottomSheet<Lang>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (_) => Directionality(
        textDirection: widget.uiLang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
        child: LanguagePicker(
          uiLang: widget.uiLang,
          allowAuto: false,
          selected: sideA ? a : b,
          recent: widget.recent,
        ),
      ),
    );
    if (picked == null) return;
    setState(() => sideA ? a = picked.code : b = picked.code);
  }

  void _toast(String m) => ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(m), behavior: SnackBarBehavior.floating));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFE9EEF6),
      appBar: AppBar(
        backgroundColor: const Color(0xFFF5F8FD),
        title: Text(t('conversation')),
        actions: [
          if (msgs.isNotEmpty)
            IconButton(
              icon: const Icon(Icons.delete_outline),
              onPressed: () => setState(msgs.clear),
            ),
        ],
      ),
      body: SafeArea(
        child: Column(children: [
          Expanded(
            child: msgs.isEmpty && partial.isEmpty
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(30),
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        const Icon(Icons.record_voice_over_outlined, size: 70, color: Colors.grey),
                        const SizedBox(height: 12),
                        Text(t('tapMic'),
                            textAlign: TextAlign.center,
                            style: const TextStyle(fontSize: 17, color: Colors.grey)),
                      ]),
                    ),
                  )
                : ListView(
                    reverse: true,
                    padding: const EdgeInsets.all(14),
                    children: [
                      if (busy) const Padding(padding: EdgeInsets.all(8), child: LinearProgressIndicator()),
                      if (partial.isNotEmpty && listening != 0)
                        _bubble(partial, '', listening == 1, live: true),
                      for (final m in msgs) _bubble(m.text, m.translated, m.sideA),
                    ],
                  ),
          ),
          Container(
            padding: const EdgeInsets.fromLTRB(12, 16, 12, 18),
            decoration: const BoxDecoration(
              color: Color(0xFFF5F8FD),
              borderRadius: BorderRadius.vertical(top: Radius.circular(30)),
            ),
            child: Row(children: [
              Expanded(child: _side(true)),
              const SizedBox(width: 12),
              Expanded(child: _side(false)),
            ]),
          ),
        ]),
      ),
    );
  }

  Widget _side(bool sideA) {
    final active = listening == (sideA ? 1 : 2);
    final color = sideA ? kBlue : kGrey;
    return Column(children: [
      GestureDetector(
        onTap: () => _listen(sideA),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          width: active ? 96 : 84,
          height: active ? 96 : 84,
          decoration: BoxDecoration(
            color: active ? Colors.redAccent : color,
            shape: BoxShape.circle,
            boxShadow: [BoxShadow(color: color.withOpacity(0.3), blurRadius: active ? 22 : 8)],
          ),
          child: Icon(active ? Icons.stop : Icons.mic, color: Colors.white, size: 40),
        ),
      ),
      const SizedBox(height: 10),
      OutlinedButton(
        onPressed: () => _pick(sideA),
        style: OutlinedButton.styleFrom(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          minimumSize: const Size.fromHeight(46),
        ),
        child: Text(_name(sideA ? a : b), overflow: TextOverflow.ellipsis),
      ),
    ]);
  }

  Widget _bubble(String text, String translated, bool sideA, {bool live = false}) {
    final color = sideA ? kBlue : kGrey;
    final to = sideA ? b : a;
    return Align(
      alignment: sideA ? AlignmentDirectional.centerStart : AlignmentDirectional.centerEnd,
      child: Container(
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.8),
        margin: const EdgeInsets.symmetric(vertical: 6),
        padding: const EdgeInsets.fromLTRB(14, 10, 6, 6),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: color.withOpacity(0.5), width: 1.5),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(text,
              textDirection: isRtl(sideA ? a : b) ? TextDirection.rtl : TextDirection.ltr,
              style: TextStyle(color: Colors.grey.shade700, fontSize: 15, fontStyle: live ? FontStyle.italic : null)),
          if (translated.isNotEmpty) ...[
            const SizedBox(height: 4),
            Row(children: [
              Expanded(
                child: Text(translated,
                    textDirection: isRtl(to) ? TextDirection.rtl : TextDirection.ltr,
                    style: TextStyle(color: color, fontSize: 20, fontWeight: FontWeight.w600)),
              ),
              IconButton(
                icon: Icon(Icons.volume_up_outlined, color: color),
                onPressed: () async {
                  await tts.setLanguage(to);
                  await tts.speak(translated);
                },
              ),
            ]),
          ],
        ]),
      ),
    );
  }
}
