import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:speech_to_text/speech_recognition_result.dart';
import 'package:speech_to_text/speech_to_text.dart';

import 'camera_page.dart';
import 'conversation.dart';
import 'languages.dart';
import 'speaker.dart';
import 'strings.dart';
import 'translator.dart';

const Color kTeal = Color(0xFF3D7BEC);
const Color kIndigo = Color(0xFF3A2FC9);
const Color kNavy = Color(0xFF12204A);

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const TraductionApp());
}

class TraductionApp extends StatefulWidget {
  const TraductionApp({super.key});
  @override
  State<TraductionApp> createState() => _TraductionAppState();
}

class _TraductionAppState extends State<TraductionApp> {
  String uiLang = 'ar';
  SharedPreferences? prefs;

  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance().then((p) {
      setState(() {
        prefs = p;
        uiLang = p.getString('uiLang') ?? 'ar';
      });
    });
  }

  void setUiLang(String l) {
    setState(() => uiLang = l);
    prefs?.setString('uiLang', l);
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Traduction',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: kTeal, primary: kTeal, secondary: kIndigo),
        scaffoldBackgroundColor: const Color(0xFFF3F6FA),
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
            seedColor: kTeal, primary: const Color(0xFF3DD6C8), brightness: Brightness.dark),
      ),
      builder: (context, child) => Directionality(
        textDirection: uiLang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
        child: child!,
      ),
      home: prefs == null
          ? const Scaffold(body: Center(child: CircularProgressIndicator()))
          : HomePage(prefs: prefs!, uiLang: uiLang, onUiLang: setUiLang),
    );
  }
}

class HistoryItem {
  final String src, out, from, to;
  bool fav;
  final int time;
  HistoryItem(this.src, this.out, this.from, this.to, this.fav, this.time);
  Map<String, dynamic> toJson() =>
      {'s': src, 'o': out, 'f': from, 't': to, 'fav': fav, 'time': time};
  factory HistoryItem.fromJson(Map<String, dynamic> j) =>
      HistoryItem(j['s'], j['o'], j['f'], j['t'], j['fav'] ?? false, j['time'] ?? 0);
}

class HomePage extends StatefulWidget {
  final SharedPreferences prefs;
  final String uiLang;
  final ValueChanged<String> onUiLang;
  const HomePage({super.key, required this.prefs, required this.uiLang, required this.onUiLang});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final translator = Translator();
  final speaker = Speaker();
  final speech = SpeechToText();
  final input = TextEditingController();
  Timer? _debounce;

  String from = 'auto';
  String to = 'ar';
  String output = '';
  bool loading = false;
  bool listening = false;
  String? error;
  List<HistoryItem> history = [];
  List<String> recent = [];

  String t(String k) => tr(widget.uiLang, k);
  SharedPreferences get p => widget.prefs;

  @override
  void initState() {
    super.initState();
    from = p.getString('from') ?? 'auto';
    to = p.getString('to') ?? (widget.uiLang == 'ar' ? 'en' : 'ar');
    recent = p.getStringList('recent') ?? ['ar', 'en', 'fr', 'es'];
    final raw = p.getString('history');
    if (raw != null) {
      history = (jsonDecode(raw) as List).map((e) => HistoryItem.fromJson(e)).toList();
    }
  }

  @override
  void dispose() {
    _debounce?.cancel();
    speaker.stop();
    speech.stop();
    input.dispose();
    super.dispose();
  }

  void _saveHistory() =>
      p.setString('history', jsonEncode(history.map((e) => e.toJson()).toList()));

  void _saveLangs() {
    p.setString('from', from);
    p.setString('to', to);
  }

  void _touchRecent(String code) {
    if (code == 'auto') return;
    recent.remove(code);
    recent.insert(0, code);
    if (recent.length > 6) recent = recent.sublist(0, 6);
    p.setStringList('recent', recent);
  }

  void _onChanged(String _) {
    setState(() {});
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 900), _translate);
  }

  Future<void> _translate({bool save = true}) async {
    _debounce?.cancel();
    final text = input.text.trim();
    if (text.isEmpty) {
      setState(() {
        output = '';
        error = null;
      });
      return;
    }
    setState(() {
      loading = true;
      error = null;
    });
    try {
      final res = await translator.translate(text, from, to);
      if (!mounted || input.text.trim() != text) return;
      setState(() => output = res);
      if (save) _addHistory(text, res);
    } on TranslateException catch (e) {
      if (mounted) setState(() => error = t(e.message));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  void _addHistory(String src, String out) {
    history.removeWhere((h) => h.src == src && h.to == to && !h.fav);
    history.insert(0, HistoryItem(src, out, from, to, false, DateTime.now().millisecondsSinceEpoch));
    if (history.length > 200) history = history.sublist(0, 200);
    _saveHistory();
  }

  void _swap() {
    if (from == 'auto') {
      from = to == 'ar' ? 'en' : 'ar';
    }
    setState(() {
      final tmp = from;
      from = to;
      to = tmp;
      if (output.isNotEmpty) {
        input.text = output;
        output = '';
      }
    });
    _saveLangs();
    _translate(save: false);
  }

  Future<void> _pickLang(bool isSource) async {
    final picked = await showModalBottomSheet<Lang>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (_) => Directionality(
        textDirection: widget.uiLang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
        child: LanguagePicker(
          uiLang: widget.uiLang,
          allowAuto: isSource,
          selected: isSource ? from : to,
          recent: recent,
        ),
      ),
    );
    if (picked == null) return;
    setState(() {
      if (isSource) {
        if (picked.code == to) to = from == 'auto' ? to : from;
        from = picked.code;
      } else {
        if (picked.code == from) from = to;
        to = picked.code;
      }
      _touchRecent(picked.code);
    });
    _saveLangs();
    _translate(save: false);
  }

  Future<void> _speak(String text, String code) async {
    if (text.trim().isEmpty) return;
    final ok = await speaker.speak(text, code);
    if (!ok) _toast('${t('noVoice')} (${_langName(code)})');
  }

  bool _voiceHandled = false;

  /// After voice input: translate, then read the translation aloud.
  Future<void> _voiceDone() async {
    if (_voiceHandled) return;
    _voiceHandled = true;
    if (mounted) setState(() => listening = false);
    if (input.text.trim().isEmpty) return;
    await _translate();
    if (mounted && output.isNotEmpty && error == null) await _speak(output, to);
  }

  Future<void> _toggleMic() async {
    if (listening) {
      await speech.stop();
      _voiceDone();
      return;
    }
    await speaker.stop();
    final ok = await speech.initialize(
      onStatus: (s) {
        if ((s == 'done' || s == 'notListening') && listening) _voiceDone();
      },
      onError: (_) {
        if (mounted) setState(() => listening = false);
      },
    );
    if (!ok) {
      _toast(t('noMic'));
      return;
    }
    _voiceHandled = false;
    setState(() => listening = true);
    await speech.listen(
      localeId: from == 'auto' ? null : from.replaceAll('-', '_'),
      onResult: (SpeechRecognitionResult r) {
        input.text = r.recognizedWords;
        setState(() {});
        if (r.finalResult) _voiceDone();
      },
    );
  }

  void _openCamera() {
    speech.stop();
    speaker.stop();
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => CameraTranslatePage(uiLang: widget.uiLang, from: from, to: to),
    ));
  }

  void _openConversation() {
    speech.stop();
    speaker.stop();
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => ConversationPage(uiLang: widget.uiLang, langA: from, langB: to, recent: recent),
    ));
  }


  void _copy(String text) {
    Clipboard.setData(ClipboardData(text: text));
    _toast(t('copied'));
  }

  Future<void> _paste() async {
    final d = await Clipboard.getData('text/plain');
    if (d?.text != null) {
      input.text = d!.text!;
      _translate();
    }
  }

  void _toast(String msg) => ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating));

  String _langName(String code) {
    if (code == 'auto') return t('detect');
    final l = langByCode(code);
    return widget.uiLang == 'en' ? l.name : (l.native.isNotEmpty ? l.native : l.name);
  }

  bool get _isFav =>
      history.isNotEmpty &&
      history.first.src == input.text.trim() &&
      history.first.out == output &&
      history.first.fav;

  void _toggleFavCurrent() {
    final src = input.text.trim();
    if (src.isEmpty || output.isEmpty) return;
    final i = history.indexWhere((h) => h.src == src && h.out == output);
    setState(() {
      if (i >= 0) {
        final h = history.removeAt(i);
        h.fav = !h.fav;
        history.insert(0, h);
      } else {
        history.insert(0, HistoryItem(src, output, from, to, true, DateTime.now().millisecondsSinceEpoch));
      }
    });
    _saveHistory();
  }

  // ---------------- Camera translation ----------------

  Future<void> _cameraMenu() async {
    final source = await showModalBottomSheet<ImageSource>(
      context: context,
      builder: (_) => Directionality(
        textDirection: widget.uiLang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
        child: SafeArea(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            ListTile(
              leading: const Icon(Icons.photo_camera_outlined),
              title: Text(t('camera')),
              onTap: () => Navigator.pop(context, ImageSource.camera),
            ),
            ListTile(
              leading: const Icon(Icons.photo_library_outlined),
              title: Text(t('gallery')),
              onTap: () => Navigator.pop(context, ImageSource.gallery),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
              child: Text(t('ocrNote'), style: const TextStyle(color: Colors.grey, fontSize: 12)),
            ),
          ]),
        ),
      ),
    );
    if (source == null) return;
    final XFile? photo = await ImagePicker().pickImage(source: source, maxWidth: 2000, imageQuality: 90);
    if (photo == null) return;
    setState(() {
      loading = true;
      error = null;
      output = '';
      input.text = '';
    });
    _toast(t('scanning'));
    final recognizer = TextRecognizer(script: TextRecognitionScript.latin);
    try {
      final result = await recognizer.processImage(InputImage.fromFilePath(photo.path));
      final text = result.blocks.map((b) => b.text.replaceAll('\n', ' ')).join('\n').trim();
      if (text.isEmpty) {
        setState(() => loading = false);
        _toast(t('noText'));
        return;
      }
      input.text = text;
      await _translate();
    } catch (e) {
      if (mounted) setState(() => loading = false);
      _toast('OCR error: $e');
    } finally {
      recognizer.close();
    }
  }

  // ---------------- UI ----------------

  static const Color kBg = Color(0xFFE9EEF6);
  static const Color kPanel = Color(0xFFF5F8FD);
  static const Color kAccent = Color(0xFF3D7BEC);

  @override
  Widget build(BuildContext context) {
    final hasResult = loading || output.isNotEmpty || error != null;
    return Scaffold(
      backgroundColor: kBg,
      body: SafeArea(
        child: Column(children: [
          // ---- Top panel: header + text + result ----
          Expanded(
            child: Container(
              decoration: const BoxDecoration(
                color: kPanel,
                borderRadius: BorderRadius.vertical(bottom: Radius.circular(36)),
              ),
              child: Column(children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(8, 6, 8, 0),
                  child: Row(children: [
                    IconButton(
                      icon: const Icon(Icons.star, size: 28),
                      tooltip: t('saved'),
                      onPressed: _openHistory,
                    ),
                    Expanded(
                      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: Image.asset('assets/icon.png', width: 30, height: 30),
                        ),
                        const SizedBox(width: 8),
                        const Text('Traduction',
                            style: TextStyle(fontSize: 24, fontWeight: FontWeight.w500)),
                      ]),
                    ),
                    IconButton(
                      icon: const Icon(Icons.settings_outlined, size: 26),
                      onPressed: _settings,
                    ),
                  ]),
                ),
                Expanded(
                  child: ListView(
                    padding: const EdgeInsets.fromLTRB(22, 18, 14, 12),
                    children: [
                      Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Expanded(
                          child: TextField(
                            controller: input,
                            onChanged: _onChanged,
                            minLines: 1,
                            maxLines: null,
                            maxLength: 3000,
                            textDirection: isRtl(from) ? TextDirection.rtl : null,
                            style: TextStyle(
                                fontSize: input.text.length > 80 ? 22 : 32,
                                color: const Color(0xFF2B2F36)),
                            decoration: InputDecoration(
                              border: InputBorder.none,
                              counterText: '',
                              hintText: listening ? t('listening') : t('enter'),
                              hintStyle: const TextStyle(color: Color(0xFF5F6670)),
                            ),
                          ),
                        ),
                        IconButton(
                          icon: Icon(input.text.isEmpty ? Icons.content_paste : Icons.close),
                          onPressed: input.text.isEmpty
                              ? _paste
                              : () => setState(() {
                                    input.clear();
                                    output = '';
                                    error = null;
                                  }),
                        ),
                      ]),
                      if (input.text.isNotEmpty)
                        Align(
                          alignment: AlignmentDirectional.centerStart,
                          child: IconButton(
                            icon: const Icon(Icons.volume_up_outlined, color: kAccent),
                            onPressed: () => _speak(input.text, from),
                          ),
                        ),
                      if (hasResult) ...[
                        const Divider(height: 28),
                        Text(_langName(to),
                            style: const TextStyle(color: kAccent, fontWeight: FontWeight.w600)),
                        const SizedBox(height: 6),
                        if (loading)
                          const Padding(
                            padding: EdgeInsets.symmetric(vertical: 18),
                            child: LinearProgressIndicator(color: kAccent),
                          )
                        else if (error != null)
                          Text(error!, style: const TextStyle(color: Colors.deepOrange, fontSize: 17))
                        else
                          SelectableText(
                            output,
                            textDirection: isRtl(to) ? TextDirection.rtl : TextDirection.ltr,
                            style: TextStyle(
                                fontSize: output.length > 80 ? 22 : 30, color: kAccent),
                          ),
                        if (!loading && output.isNotEmpty)
                          Row(children: [
                            IconButton(
                              icon: const Icon(Icons.volume_up_outlined),
                              onPressed: () => _speak(output, to),
                            ),
                            IconButton(icon: const Icon(Icons.copy), onPressed: () => _copy(output)),
                            const Spacer(),
                            IconButton(
                              icon: Icon(_isFav ? Icons.star : Icons.star_border),
                              onPressed: _toggleFavCurrent,
                            ),
                          ]),
                      ],
                    ],
                  ),
                ),
                Container(
                  width: 48,
                  height: 5,
                  margin: const EdgeInsets.only(bottom: 12),
                  decoration: BoxDecoration(
                    color: const Color(0xFFC4C9D2),
                    borderRadius: BorderRadius.circular(3),
                  ),
                ),
              ]),
            ),
          ),
          // ---- Language selector ----
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 8),
            child: Row(children: [
              Expanded(child: _langButton(true)),
              IconButton(
                icon: const Icon(Icons.swap_horiz, size: 30),
                onPressed: _swap,
              ),
              Expanded(child: _langButton(false)),
            ]),
          ),
          // ---- Actions: history · mic · camera ----
          Padding(
            padding: const EdgeInsets.fromLTRB(8, 10, 8, 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _sideAction(Icons.record_voice_over_outlined, t('conversation'), _openConversation),
                GestureDetector(
                  onTap: _toggleMic,
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 250),
                    width: listening ? 112 : 104,
                    height: listening ? 112 : 104,
                    decoration: BoxDecoration(
                      color: listening ? Colors.redAccent : kAccent,
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: (listening ? Colors.redAccent : kAccent).withOpacity(0.35),
                          blurRadius: listening ? 24 : 10,
                        ),
                      ],
                    ),
                    child: Icon(listening ? Icons.stop : Icons.mic, color: Colors.white, size: 46),
                  ),
                ),
                _sideAction(Icons.camera_alt_outlined, t('camera'), _openCamera),
              ],
            ),
          ),
        ]),
      ),
    );
  }

  Widget _sideAction(IconData icon, String label, VoidCallback onTap) {
    return SizedBox(
      width: 110,
      child: Column(children: [
        const SizedBox(height: 14),
        Material(
          color: const Color(0xFFD3E3F0),
          shape: const CircleBorder(),
          child: InkWell(
            customBorder: const CircleBorder(),
            onTap: onTap,
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Icon(icon, size: 28, color: const Color(0xFF1D2A3A)),
            ),
          ),
        ),
        const SizedBox(height: 8),
        Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 14)),
      ]),
    );
  }

  Widget _langButton(bool isSource) {
    final code = isSource ? from : to;
    return Material(
      color: kPanel,
      borderRadius: BorderRadius.circular(22),
      child: InkWell(
        borderRadius: BorderRadius.circular(22),
        onTap: () => _pickLang(isSource),
        child: SizedBox(
          height: 64,
          child: Center(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: Text(
                _langName(code),
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w500),
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _openHistory() {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => StatefulBuilder(
        builder: (ctx, setLocal) {
          void refresh() {
            setLocal(() {});
            setState(() {});
          }

          return DefaultTabController(
            length: 2,
            child: Scaffold(
              appBar: AppBar(
                title: Text(t('history')),
                bottom: TabBar(tabs: [Tab(text: t('history')), Tab(text: t('saved'))]),
              ),
              body: TabBarView(children: [
                _historyList(ctx, false, refresh),
                _historyList(ctx, true, refresh),
              ]),
            ),
          );
        },
      ),
    ));
  }

  Widget _historyList(BuildContext ctx, bool favOnly, VoidCallback refresh) {
    final items = favOnly ? history.where((h) => h.fav).toList() : history;
    if (items.isEmpty) {
      return Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(favOnly ? Icons.star_border : Icons.history, size: 64, color: Colors.grey),
          const SizedBox(height: 8),
          Text(t('empty'), style: const TextStyle(color: Colors.grey)),
        ]),
      );
    }
    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        if (!favOnly)
          Align(
            alignment: AlignmentDirectional.centerEnd,
            child: TextButton.icon(
              icon: const Icon(Icons.delete_outline),
              label: Text(t('clearHistory')),
              onPressed: () {
                history.removeWhere((h) => !h.fav);
                _saveHistory();
                refresh();
              },
            ),
          ),
        for (final h in items)
          Card(
            elevation: 0,
            margin: const EdgeInsets.symmetric(vertical: 4),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: ListTile(
              title: Text(h.src, maxLines: 2, overflow: TextOverflow.ellipsis),
              subtitle: Text('${_langName(h.from)} → ${_langName(h.to)}\n${h.out}',
                  maxLines: 3, overflow: TextOverflow.ellipsis),
              isThreeLine: true,
              trailing: IconButton(
                icon: Icon(h.fav ? Icons.star : Icons.star_border, color: Colors.amber),
                onPressed: () {
                  h.fav = !h.fav;
                  _saveHistory();
                  refresh();
                },
              ),
              onTap: () {
                Navigator.pop(ctx);
                setState(() {
                  from = h.from;
                  to = h.to;
                  input.text = h.src;
                  output = h.out;
                  error = null;
                });
              },
            ),
          ),
      ],
    );
  }


  void _settings() {
    showModalBottomSheet(
      context: context,
      builder: (_) => Directionality(
        textDirection: widget.uiLang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
        child: SafeArea(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            ListTile(title: Text(t('appLang'), style: const TextStyle(fontWeight: FontWeight.bold))),
            for (final e in const {'ar': 'العربية', 'en': 'English', 'fr': 'Français'}.entries)
              ListTile(
                leading: Icon(widget.uiLang == e.key
                    ? Icons.radio_button_checked
                    : Icons.radio_button_off),
                title: Text(e.value),
                onTap: () {
                  widget.onUiLang(e.key);
                  Navigator.pop(context);
                },
              ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.info_outline),
              title: Text(t('about')),
              subtitle: Text(t('aboutText')),
            ),
          ]),
        ),
      ),
    );
  }
}

class LanguagePicker extends StatefulWidget {
  final String uiLang;
  final bool allowAuto;
  final String selected;
  final List<String> recent;
  const LanguagePicker(
      {super.key,
      required this.uiLang,
      required this.allowAuto,
      required this.selected,
      required this.recent});
  @override
  State<LanguagePicker> createState() => _LanguagePickerState();
}

class _LanguagePickerState extends State<LanguagePicker> {
  String q = '';

  Widget _tile(Lang l) {
    final sel = l.code == widget.selected;
    return ListTile(
      leading: Icon(sel ? Icons.check_circle : Icons.language,
          color: sel ? Theme.of(context).colorScheme.primary : Colors.grey),
      title: Text(l.code == 'auto' ? tr(widget.uiLang, 'detect') : l.native),
      subtitle: l.code == 'auto' ? null : Text(l.name),
      onTap: () => Navigator.pop(context, l),
    );
  }

  @override
  Widget build(BuildContext context) {
    final query = q.toLowerCase();
    final filtered = languages
        .where((l) =>
            query.isEmpty ||
            l.name.toLowerCase().contains(query) ||
            l.native.toLowerCase().contains(query) ||
            l.code.toLowerCase() == query)
        .toList();
    return DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.9,
      builder: (_, ctrl) => Column(children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: TextField(
            autofocus: false,
            onChanged: (v) => setState(() => q = v),
            decoration: InputDecoration(
              prefixIcon: const Icon(Icons.search),
              hintText: tr(widget.uiLang, 'search'),
              filled: true,
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30), borderSide: BorderSide.none),
            ),
          ),
        ),
        Expanded(
          child: ListView(controller: ctrl, children: [
            if (query.isEmpty && widget.allowAuto) _tile(autoDetect),
            if (query.isEmpty && widget.recent.isNotEmpty) ...[
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
                child: Text(tr(widget.uiLang, 'recent'),
                    style: Theme.of(context).textTheme.labelLarge),
              ),
              ...widget.recent.map((c) => _tile(langByCode(c))),
              const Divider(),
            ],
            ...filtered.map(_tile),
          ]),
        ),
      ]),
    );
  }
}
