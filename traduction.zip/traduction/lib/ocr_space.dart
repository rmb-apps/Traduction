import 'dart:convert';
import 'dart:typed_data';
import 'dart:ui';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:image/image.dart' as img;

class OcrException implements Exception {
  final String message; // key of a UI string
  OcrException(this.message);
  @override
  String toString() => message;
}

class OcrLine {
  final Rect rect;
  final String text;
  OcrLine(this.rect, this.text);
}

/// Online text reading (OCR.space) for scripts the on-device reader does
/// not support, mainly Arabic. The API key is injected at build time:
///   flutter build apk --dart-define=OCR_SPACE_KEY=xxxx
class OcrSpace {
  static const String apiKey = String.fromEnvironment('OCR_SPACE_KEY');

  /// App language code -> OCR.space language code.
  static const Map<String, String> _langs = {
    'ar': 'ara',
    'fa': 'per',
    'ur': 'urd',
    'ru': 'rus',
    'uk': 'ukr',
    'bg': 'bul',
    'el': 'gre',
    'zh-CN': 'chs',
    'zh-TW': 'cht',
    'ja': 'jpn',
    'ko': 'kor',
    'hi': 'hin',
    'th': 'tha',
  };

  /// True when images in this source language must be read online.
  static bool handles(String from) => _langs.containsKey(from);

  /// Reads the text lines of a photo. Returned rectangles are in the
  /// coordinates of an image of size [originalSize].
  static Future<List<OcrLine>> read(Uint8List fileBytes, String from, Size originalSize) async {
    if (apiKey.isEmpty) throw OcrException('ocrKey');
    final prepared = await compute(_prepare, fileBytes);
    final jpeg = prepared['bytes'] as Uint8List;
    final w = prepared['w'] as int;
    final scale = originalSize.width / w;

    Map<String, dynamic>? data;
    for (final engine in ['3', '1']) {
      data = await _post(jpeg, _langs[from]!, engine);
      if (data['IsErroredOnProcessing'] != true) break;
    }
    if (data == null || data['IsErroredOnProcessing'] == true) {
      throw OcrException('ocrFail');
    }
    final results = data['ParsedResults'] as List? ?? [];
    final lines = <OcrLine>[];
    for (final r in results) {
      final overlay = r['TextOverlay'];
      final ls = overlay == null ? null : overlay['Lines'] as List?;
      if (ls == null) continue;
      for (final l in ls) {
        final words = l['Words'] as List? ?? [];
        if (words.isEmpty) continue;
        double left = double.infinity, top = double.infinity, right = 0, bottom = 0;
        for (final wd in words) {
          final x = (wd['Left'] as num).toDouble(), y = (wd['Top'] as num).toDouble();
          final ww = (wd['Width'] as num).toDouble(), hh = (wd['Height'] as num).toDouble();
          if (x < left) left = x;
          if (y < top) top = y;
          if (x + ww > right) right = x + ww;
          if (y + hh > bottom) bottom = y + hh;
        }
        final text = (l['LineText'] ?? '').toString().trim();
        if (text.isEmpty) continue;
        lines.add(OcrLine(
          Rect.fromLTRB(left * scale, top * scale, right * scale, bottom * scale),
          text,
        ));
      }
    }
    return lines;
  }

  static Future<Map<String, dynamic>> _post(Uint8List jpeg, String lang, String engine) async {
    final req = http.MultipartRequest('POST', Uri.parse('https://api.ocr.space/parse/image'))
      ..headers['apikey'] = apiKey
      ..fields['language'] = lang
      ..fields['isOverlayRequired'] = 'true'
      ..fields['OCREngine'] = engine
      ..fields['scale'] = 'true'
      ..files.add(http.MultipartFile.fromBytes('file', jpeg, filename: 'photo.jpg'));
    http.Response res;
    try {
      res = await http.Response.fromStream(await req.send().timeout(const Duration(seconds: 40)));
    } catch (_) {
      throw OcrException('network');
    }
    if (res.statusCode == 403 || res.statusCode == 429) throw OcrException('quota');
    if (res.statusCode != 200) throw OcrException('ocrFail');
    final body = jsonDecode(utf8.decode(res.bodyBytes));
    if (body is! Map<String, dynamic>) throw OcrException('ocrFail');
    return body;
  }
}

/// Runs in a background isolate: upright, at most 1600 px wide, JPEG under 1 MB
/// (the free OCR.space plan refuses files over 1 MB).
Map<String, dynamic> _prepare(Uint8List bytes) {
  var im = img.decodeImage(bytes);
  if (im == null) throw OcrException('ocrFail');
  im = img.bakeOrientation(im);
  if (im.width > 1600) im = img.copyResize(im, width: 1600);
  var quality = 85;
  var out = img.encodeJpg(im, quality: quality);
  while (out.length > 950 * 1024 && quality > 40) {
    quality -= 15;
    out = img.encodeJpg(im, quality: quality);
  }
  return {'bytes': Uint8List.fromList(out), 'w': im.width};
}

/// Groups lines that belong to the same paragraph, so each paragraph is
/// translated as a whole (better than line by line).
List<OcrLine> groupLines(List<OcrLine> lines) {
  if (lines.isEmpty) return lines;
  final sorted = [...lines]..sort((a, b) => a.rect.top.compareTo(b.rect.top));
  final groups = <OcrLine>[];
  var cur = sorted.first;
  for (final l in sorted.skip(1)) {
    final h = cur.rect.height / (cur.text.split('\n').length);
    final gap = l.rect.top - cur.rect.bottom;
    final overlap = (l.rect.right < cur.rect.left || l.rect.left > cur.rect.right) ? false : true;
    final similarSize = (l.rect.height - h).abs() < h * 0.5;
    if (gap < h * 0.8 && overlap && similarSize) {
      cur = OcrLine(cur.rect.expandToInclude(l.rect), '${cur.text}\n${l.text}');
    } else {
      groups.add(cur);
      cur = l;
    }
  }
  groups.add(cur);
  return groups;
}
