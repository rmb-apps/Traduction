import 'package:google_mlkit_translation/google_mlkit_translation.dart';

/// On-device translation (no internet) with downloadable language packs.
/// English is always available; other languages are downloaded by the user.
class Offline {
  static final _manager = OnDeviceTranslatorModelManager();
  static const _aliases = {'fil': 'tl', 'zh-CN': 'zh', 'zh-TW': 'zh'};

  static TranslateLanguage? lang(String code) {
    final c = _aliases[code] ?? code.split('-').first;
    for (final l in TranslateLanguage.values) {
      if (l.bcpCode == c) return l;
    }
    return null;
  }

  static bool supported(String code) => lang(code) != null;

  /// Identifier of the language pack (zh-CN and zh-TW share one).
  static String packId(String code) => lang(code)!.bcpCode;

  static final Set<String> _ready = {'en'};

  static Future<bool> isDownloaded(String code) async {
    final l = lang(code);
    if (l == null) return false;
    if (l == TranslateLanguage.english || _ready.contains(l.bcpCode)) return true;
    try {
      final ok = await _manager.isModelDownloaded(l.bcpCode);
      if (ok) _ready.add(l.bcpCode);
      return ok;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> download(String code) =>
      _manager.downloadModel(lang(code)!.bcpCode, isWifiRequired: false);

  static Future<bool> delete(String code) {
    _ready.remove(lang(code)!.bcpCode);
    for (final t in _translators.values) {
      t.close();
    }
    _translators.clear();
    return _manager.deleteModel(lang(code)!.bcpCode);
  }

  static Future<bool> canTranslate(String from, String to) async =>
      supported(from) && supported(to) && await isDownloaded(from) && await isDownloaded(to);

  // Translators stay loaded in memory: creating one takes time.
  static final Map<String, OnDeviceTranslator> _translators = {};

  static OnDeviceTranslator _get(String from, String to) {
    final key = '${lang(from)!.bcpCode}>${lang(to)!.bcpCode}';
    return _translators.putIfAbsent(
        key, () => OnDeviceTranslator(sourceLanguage: lang(from)!, targetLanguage: lang(to)!));
  }

  static Future<String> translate(String text, String from, String to) =>
      _get(from, to).translateText(text);

  /// Loads the engine in advance so the first translation is fast.
  static Future<void> warmUp(String from, String to) async {
    if (from == 'auto' || from == to || !supported(from) || !supported(to)) return;
    if (!await isDownloaded(from) || !await isDownloaded(to)) return;
    try {
      await translate('ok', from, to);
    } catch (_) {}
  }
}
