import 'package:google_mlkit_translation/google_mlkit_translation.dart';

/// On-device translation (no internet) with downloadable language packs.
/// English is always available; other languages are downloaded by the user.
class Offline {
  static final _manager = OnDeviceTranslatorModelManager();
  static const _aliases = {'fil': 'tl', 'zh-CN': 'zh', 'zh-TW': 'zh'};

  static TranslateLanguage? lang(String code) {
    final c = _aliases[code] ?? code.split('-').first;
    for (final l in TranslateLanguage.values) {
      if (l.bcpCode == c) return l;
    }
    return null;
  }

  static bool supported(String code) => lang(code) != null;

  static Future<bool> isDownloaded(String code) async {
    final l = lang(code);
    if (l == null) return false;
    if (l == TranslateLanguage.english) return true;
    try {
      return await _manager.isModelDownloaded(l.bcpCode);
    } catch (_) {
      return false;
    }
  }

  static Future<bool> download(String code) =>
      _manager.downloadModel(lang(code)!.bcpCode, isWifiRequired: false);

  static Future<bool> delete(String code) => _manager.deleteModel(lang(code)!.bcpCode);

  static Future<bool> canTranslate(String from, String to) async =>
      supported(from) && supported(to) && await isDownloaded(from) && await isDownloaded(to);

  static Future<String> translate(String text, String from, String to) async {
    final t = OnDeviceTranslator(sourceLanguage: lang(from)!, targetLanguage: lang(to)!);
    try {
      return await t.translateText(text);
    } finally {
      t.close();
    }
  }
}
