import 'package:flutter/material.dart';

import 'languages.dart';
import 'offline.dart';
import 'strings.dart';

/// Lets the user download / delete language packs for offline translation.
/// English is built in; every other language is optional.
class OfflinePage extends StatefulWidget {
  final String uiLang;
  const OfflinePage({super.key, required this.uiLang});
  @override
  State<OfflinePage> createState() => _OfflinePageState();
}

class _OfflinePageState extends State<OfflinePage> {
  final Map<String, bool> downloaded = {};
  final Set<String> busy = {};
  bool loading = true;
  String q = '';

  String t(String k) => tr(widget.uiLang, k);

  List<Lang> get _langs {
    final seen = <String>{};
    final list = languages.where((l) {
      if (!Offline.supported(l.code)) return false;
      final key = Offline.packId(l.code);
      return seen.add(key); // zh-CN / zh-TW share one pack
    }).toList();
    return list;
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    for (final l in _langs) {
      downloaded[l.code] = await Offline.isDownloaded(l.code);
    }
    if (mounted) setState(() => loading = false);
  }

  Future<void> _download(Lang l) async {
    setState(() => busy.add(l.code));
    try {
      await Offline.download(l.code);
      downloaded[l.code] = await Offline.isDownloaded(l.code);
    } catch (e) {
      _toast('${t('server')} ($e)');
    }
    if (mounted) setState(() => busy.remove(l.code));
  }

  Future<void> _delete(Lang l) async {
    setState(() => busy.add(l.code));
    try {
      await Offline.delete(l.code);
      downloaded[l.code] = false;
    } catch (_) {}
    if (mounted) setState(() => busy.remove(l.code));
  }

  void _toast(String m) => ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(m), behavior: SnackBarBehavior.floating));

  String _name(Lang l) => widget.uiLang == 'en' ? l.name : l.native;

  Widget _tile(Lang l) {
    final isEn = l.code == 'en';
    final done = downloaded[l.code] == true;
    final working = busy.contains(l.code);
    Widget trailing;
    if (isEn) {
      trailing = Chip(label: Text(t('builtIn')));
    } else if (working) {
      trailing = const SizedBox(width: 28, height: 28, child: CircularProgressIndicator(strokeWidth: 3));
    } else if (done) {
      trailing = IconButton(
        tooltip: t('delete'),
        icon: const Icon(Icons.delete_outline),
        onPressed: () => _delete(l),
      );
    } else {
      trailing = IconButton(
        tooltip: t('download'),
        icon: const Icon(Icons.download_for_offline_outlined, color: Color(0xFF3D7BEC)),
        onPressed: () => _download(l),
      );
    }
    return ListTile(
      leading: Icon(isEn || done ? Icons.offline_pin : Icons.language,
          color: isEn || done ? const Color(0xFF3D7BEC) : Colors.grey),
      title: Text(_name(l)),
      subtitle: Text(isEn
          ? l.name
          : working
              ? t('downloading')
              : '${l.name} · ${t('size')}'),
      trailing: trailing,
    );
  }

  @override
  Widget build(BuildContext context) {
    final query = q.toLowerCase();
    final all = _langs
        .where((l) =>
            query.isEmpty || l.name.toLowerCase().contains(query) || l.native.toLowerCase().contains(query))
        .toList();
    final en = all.where((l) => l.code == 'en');
    final mine = all.where((l) => l.code != 'en' && downloaded[l.code] == true);
    final rest = all.where((l) => l.code != 'en' && downloaded[l.code] != true);
    return Scaffold(
      appBar: AppBar(title: Text(t('offline'))),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
                child: Text(t('offlineInfo'), style: const TextStyle(color: Colors.grey)),
              ),
              Padding(
                padding: const EdgeInsets.all(12),
                child: TextField(
                  onChanged: (v) => setState(() => q = v),
                  decoration: InputDecoration(
                    prefixIcon: const Icon(Icons.search),
                    hintText: t('search'),
                    filled: true,
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(30), borderSide: BorderSide.none),
                  ),
                ),
              ),
              ...en.map(_tile),
              ...mine.map(_tile),
              if (rest.isNotEmpty) const Divider(),
              ...rest.map(_tile),
            ]),
    );
  }
}
