import 'package:flutter_tts/flutter_tts.dart';

/// Reads text aloud with the phone's text-to-speech engine.
/// Finds an installed voice that matches the language (e.g. "ar" -> "ar-SA").
class Speaker {
  final FlutterTts tts = FlutterTts();
  bool _ready = false;
  List<String> _langs = [];

  Future<void> _setup() async {
    if (_ready) return;
    _ready = true;
    try {
      await tts.setVolume(1.0);
      await tts.setSpeechRate(0.45);
      await tts.setPitch(1.0);
      final l = await tts.getLanguages;
      if (l is List) _langs = l.map((e) => e.toString().replaceAll('_', '-')).toList();
    } catch (_) {}
  }

  Future<void> stop() async {
    try {
      await tts.stop();
    } catch (_) {}
  }

  /// Returns false when no voice for this language is installed on the phone.
  Future<bool> speak(String text, String code) async {
    text = text.trim();
    if (text.isEmpty) return true;
    await _setup();
    await stop();
    if (_langs.isEmpty) {
      // Engine not ready yet: try again to read the list once.
      try {
        final l = await tts.getLanguages;
        if (l is List) _langs = l.map((e) => e.toString().replaceAll('_', '-')).toList();
      } catch (_) {}
    }
    if (code != 'auto') {
      final aliases = {'he': 'iw', 'fil': 'tl', 'jv': 'jw'};
      final want = code.toLowerCase();
      final base = want.split('-').first;
      String? match;
      for (final l in _langs) {
        if (l.toLowerCase() == want) match = l;
      }
      match ??= _firstWhereOrNull(_langs, (l) {
        final b = l.toLowerCase().split('-').first;
        return b == base || b == aliases[base];
      });
      if (match == null && _langs.isNotEmpty) return false;
      try {
        await tts.setLanguage(match ?? code);
      } catch (_) {}
    }
    try {
      await tts.speak(text);
    } catch (_) {
      return false;
    }
    return true;
  }

  String? _firstWhereOrNull(List<String> list, bool Function(String) test) {
    for (final e in list) {
      if (test(e)) return e;
    }
    return null;
  }
}
