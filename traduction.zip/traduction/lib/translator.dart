import 'dart:convert';
import 'package:http/http.dart' as http;

import 'package:google_mlkit_language_id/google_mlkit_language_id.dart';

import 'languages.dart';
import 'offline.dart';

class TranslateException implements Exception {
  final String message;
  final String detail; // server explanation, shown to help find problems
  TranslateException(this.message, [this.detail = '']);
  @override
  String toString() => message;
}

/// Free translation through the MyMemory API (no key needed).
/// Put your contact email in [contactEmail] to raise the free daily
/// quota from ~5,000 to ~50,000 characters.
class Translator {
  static const String contactEmail = 'rmb.contact147@gmail.com';
  static const int _maxBytes = 450; // API limit is 500 bytes per request

  /// Called when a language pack starts downloading (to inform the user).
  void Function(String code)? onDownloading;

  Future<String> translate(String text, String from, String to) async {
    text = text.trim();
    if (text.isEmpty) return '';
    if (from == to) return text;
    if (from == 'auto') {
      final found = await detectLanguage(text)
          .timeout(const Duration(seconds: 2), onTimeout: () => null);
      if (found != null) {
        if (found == to) return text;
        from = found;
      }
    }
    // 1) Google ML Kit on the phone: best quality, works offline.
    //    Language packs (~30 MB) are downloaded automatically the first time.
    if (from != 'auto' && Offline.supported(from) && Offline.supported(to)) {
      try {
        for (final c in [from, to]) {
          if (!await Offline.isDownloaded(c)) {
            onDownloading?.call(c);
            await Offline.download(c).timeout(const Duration(minutes: 3));
          }
        }
        final r = await Offline.translate(text, from, to);
        if (r.trim().isNotEmpty) return r;
      } catch (_) {
        // Pack not available yet (no internet...): fall back to online.
      }
    }
    // 2) Online service for the other languages (or as a fallback).
    try {
      return await _online(text, from, to);
    } on TranslateException catch (e) {
      if (e.message != 'network') rethrow;
      // No internet: use the downloaded language packs if possible.
      if (from == 'auto') {
        if (Offline.supported(to) && await Offline.isDownloaded(to)) {
          throw TranslateException('offlineAuto', e.detail);
        }
        rethrow;
      }
      if (await Offline.canTranslate(from, to)) {
        try {
          return await Offline.translate(text, from, to);
        } catch (_) {
          throw TranslateException('server');
        }
      }
      if (Offline.supported(from) && Offline.supported(to)) {
        throw TranslateException('offlineMissing', e.detail);
      }
      rethrow;
    }
  }

  /// Detects the language on the phone (no internet needed).
  /// Returns an app language code, or null when unsure.
  static Future<String?> detectLanguage(String text) async {
    final id = LanguageIdentifier(confidenceThreshold: 0.4);
    try {
      final code = await id.identifyLanguage(text);
      if (code == 'und') return null;
      const map = {'zh': 'zh-CN', 'zh-Latn': 'zh-CN', 'iw': 'he', 'tl': 'fil', 'jw': 'jv'};
      final c = map[code] ?? code.split('-').first;
      return languages.any((l) => l.code == c) ? c : null;
    } catch (_) {
      return null;
    } finally {
      id.close();
    }
  }

  Future<String> _online(String text, String from, String to) async {
    final parts = _split(text);
    final out = <String>[];
    out.addAll(await Future.wait(
        parts.map((p) => p.trim().isEmpty ? Future.value(p) : _one(p, from, to))));
    return out.join(' ').replaceAll(RegExp(r' *\n *'), '\n');
  }

  static final http.Client _client = http.Client();
  static final Map<String, String> _cache = {};

  Future<String> _one(String q, String from, String to) async {
    final key = '$from|$to|$q';
    final hit = _cache[key];
    if (hit != null) return hit;
    final r = await _fetch(q, from, to);
    if (_cache.length > 300) _cache.clear();
    _cache[key] = r;
    return r;
  }

  Future<String> _fetch(String q, String from, String to) async {
    final src = from == 'auto' ? 'Autodetect' : from;
    final uri = Uri.https('api.mymemory.translated.net', '/get', {
      'q': q,
      'langpair': '$src|$to',
      'mt': '1',
      if (contactEmail.isNotEmpty) 'de': contactEmail,
    });
    http.Response res;
    try {
      res = await _client.get(uri).timeout(const Duration(seconds: 10));
    } catch (_) {
      try {
        // One quick retry: a first request on a new connection can stall.
        res = await _client.get(uri).timeout(const Duration(seconds: 12));
      } catch (e) {
        throw TranslateException('network', e.toString().split('\n').first);
      }
    }
    if (res.statusCode == 429) throw TranslateException('quota');
    if (res.statusCode != 200) throw TranslateException('server', 'HTTP ${res.statusCode}');
    final data = jsonDecode(utf8.decode(res.bodyBytes));
    final status = data['responseStatus'];
    final translated = (data['responseData']?['translatedText'] ?? '').toString();
    if (status.toString() == '429' || translated.contains('MYMEMORY WARNING')) {
      throw TranslateException('quota');
    }
    if (status.toString() != '200' || translated.isEmpty) {
      throw TranslateException('server', (data['responseDetails'] ?? status).toString());
    }
    return _unescape(_best(data, q, to) ?? translated);
  }

  /// MyMemory mixes machine translation with user-contributed memories,
  /// which are often wrong. Prefer the machine translation, and never
  /// accept a result written in the wrong script for the target language.
  String? _best(dynamic data, String q, String to) {
    final matches = (data['matches'] as List?) ?? const [];
    String? mt;
    final others = <String>[];
    for (final m in matches) {
      final tr = (m['translation'] ?? '').toString().trim();
      if (tr.isEmpty || tr.toLowerCase() == q.trim().toLowerCase()) continue;
      if (!_scriptOk(tr, to)) continue;
      if (m['created-by'] == 'MT!' || m['reference'] == 'Machine Translation.') {
        mt ??= tr;
      } else {
        others.add(tr);
      }
    }
    final main = (data['responseData']?['translatedText'] ?? '').toString();
    if (mt != null) return mt;
    if (_scriptOk(main, to)) return main;
    return others.isNotEmpty ? others.first : null;
  }

  static final Map<String, RegExp> _scripts = {
    'ar': RegExp(r'[\u0600-\u06FF]'), 'fa': RegExp(r'[\u0600-\u06FF]'),
    'ur': RegExp(r'[\u0600-\u06FF]'), 'ps': RegExp(r'[\u0600-\u06FF]'),
    'he': RegExp(r'[\u0590-\u05FF]'), 'yi': RegExp(r'[\u0590-\u05FF]'),
    'ru': RegExp(r'[\u0400-\u04FF]'), 'uk': RegExp(r'[\u0400-\u04FF]'),
    'bg': RegExp(r'[\u0400-\u04FF]'), 'el': RegExp(r'[\u0370-\u03FF]'),
    'zh-CN': RegExp(r'[\u4E00-\u9FFF]'), 'zh-TW': RegExp(r'[\u4E00-\u9FFF]'),
    'ja': RegExp(r'[\u3040-\u30FF\u4E00-\u9FFF]'), 'ko': RegExp(r'[\uAC00-\uD7AF]'),
    'hi': RegExp(r'[\u0900-\u097F]'), 'th': RegExp(r'[\u0E00-\u0E7F]'),
  };

  /// For languages with their own alphabet, the text must contain it.
  bool _scriptOk(String text, String to) {
    final re = _scripts[to];
    return re == null || re.hasMatch(text);
  }

  /// Splits long text into pieces under the API byte limit,
  /// preferring sentence and line boundaries.
  List<String> _split(String text) {
    final pieces = <String>[];
    final sentences = text.split(RegExp(r'(?<=[.!?؟。\n])\s*'));
    var current = '';
    for (final s in sentences) {
      final candidate = current.isEmpty ? s : '$current $s';
      if (utf8.encode(candidate).length <= _maxBytes) {
        current = candidate;
      } else {
        if (current.isNotEmpty) pieces.add(current);
        if (utf8.encode(s).length <= _maxBytes) {
          current = s;
        } else {
          // Very long sentence: cut by words.
          current = '';
          for (final w in s.split(' ')) {
            final c = current.isEmpty ? w : '$current $w';
            if (utf8.encode(c).length <= _maxBytes) {
              current = c;
            } else {
              if (current.isNotEmpty) pieces.add(current);
              current = w;
            }
          }
        }
      }
    }
    if (current.isNotEmpty) pieces.add(current);
    return pieces;
  }

  String _unescape(String s) => s
      .replaceAll('&quot;', '"')
      .replaceAll('&#39;', "'")
      .replaceAll('&amp;', '&')
      .replaceAll('&lt;', '<')
      .replaceAll('&gt;', '>');
}
