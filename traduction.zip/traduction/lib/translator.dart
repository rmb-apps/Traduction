import 'dart:convert';
import 'package:http/http.dart' as http;

import 'package:google_mlkit_language_id/google_mlkit_language_id.dart';

import 'languages.dart';
import 'offline.dart';

class TranslateException implements Exception {
  final String message;
  final String detail; // server explanation, shown to help find problems
  TranslateException(this.message, [this.detail = '']);
  @override
  String toString() => message;
}

/// Free translation through the MyMemory API (no key needed).
/// Put your contact email in [contactEmail] to raise the free daily
/// quota from ~5,000 to ~50,000 characters.
class Translator {
  static const String contactEmail = 'rmb.contact147@gmail.com';
  static const int _maxBytes = 450; // API limit is 500 bytes per request

  Future<String> translate(String text, String from, String to) async {
    text = text.trim();
    if (text.isEmpty) return '';
    if (from == to) return text;
    if (from == 'auto') {
      final found = await detectLanguage(text);
      if (found != null) {
        if (found == to) return text;
        from = found;
      }
    }
    try {
      return await _online(text, from, to);
    } on TranslateException catch (e) {
      if (e.message != 'network') rethrow;
      // No internet: use the downloaded language packs if possible.
      if (from == 'auto') {
        if (Offline.supported(to) && await Offline.isDownloaded(to)) {
          throw TranslateException('offlineAuto', e.detail);
        }
        rethrow;
      }
      if (await Offline.canTranslate(from, to)) {
        try {
          return await Offline.translate(text, from, to);
        } catch (_) {
          throw TranslateException('server');
        }
      }
      if (Offline.supported(from) && Offline.supported(to)) {
        throw TranslateException('offlineMissing', e.detail);
      }
      rethrow;
    }
  }

  /// Detects the language on the phone (no internet needed).
  /// Returns an app language code, or null when unsure.
  static Future<String?> detectLanguage(String text) async {
    final id = LanguageIdentifier(confidenceThreshold: 0.4);
    try {
      final code = await id.identifyLanguage(text);
      if (code == 'und') return null;
      const map = {'zh': 'zh-CN', 'zh-Latn': 'zh-CN', 'iw': 'he', 'tl': 'fil', 'jw': 'jv'};
      final c = map[code] ?? code.split('-').first;
      return languages.any((l) => l.code == c) ? c : null;
    } catch (_) {
      return null;
    } finally {
      id.close();
    }
  }

  Future<String> _online(String text, String from, String to) async {
    final parts = _split(text);
    final out = <String>[];
    for (final p in parts) {
      out.add(p.trim().isEmpty ? p : await _one(p, from, to));
    }
    return out.join(' ').replaceAll(RegExp(r' *\n *'), '\n');
  }

  Future<String> _one(String q, String from, String to) async {
    final src = from == 'auto' ? 'Autodetect' : from;
    final uri = Uri.https('api.mymemory.translated.net', '/get', {
      'q': q,
      'langpair': '$src|$to',
      if (contactEmail.isNotEmpty) 'de': contactEmail,
    });
    http.Response res;
    try {
      res = await http.get(uri).timeout(const Duration(seconds: 20));
    } catch (e) {
      throw TranslateException('network', e.toString().split('\n').first);
    }
    if (res.statusCode == 429) throw TranslateException('quota');
    if (res.statusCode != 200) throw TranslateException('server', 'HTTP ${res.statusCode}');
    final data = jsonDecode(utf8.decode(res.bodyBytes));
    final status = data['responseStatus'];
    final translated = (data['responseData']?['translatedText'] ?? '').toString();
    if (status.toString() == '429' || translated.contains('MYMEMORY WARNING')) {
      throw TranslateException('quota');
    }
    if (status.toString() != '200' || translated.isEmpty) {
      throw TranslateException('server', (data['responseDetails'] ?? status).toString());
    }
    return _unescape(translated);
  }

  /// Splits long text into pieces under the API byte limit,
  /// preferring sentence and line boundaries.
  List<String> _split(String text) {
    final pieces = <String>[];
    final sentences = text.split(RegExp(r'(?<=[.!?؟。\n])\s*'));
    var current = '';
    for (final s in sentences) {
      final candidate = current.isEmpty ? s : '$current $s';
      if (utf8.encode(candidate).length <= _maxBytes) {
        current = candidate;
      } else {
        if (current.isNotEmpty) pieces.add(current);
        if (utf8.encode(s).length <= _maxBytes) {
          current = s;
        } else {
          // Very long sentence: cut by words.
          current = '';
          for (final w in s.split(' ')) {
            final c = current.isEmpty ? w : '$current $w';
            if (utf8.encode(c).length <= _maxBytes) {
              current = c;
            } else {
              if (current.isNotEmpty) pieces.add(current);
              current = w;
            }
          }
        }
      }
    }
    if (current.isNotEmpty) pieces.add(current);
    return pieces;
  }

  String _unescape(String s) => s
      .replaceAll('&quot;', '"')
      .replaceAll('&#39;', "'")
      .replaceAll('&amp;', '&')
      .replaceAll('&lt;', '<')
      .replaceAll('&gt;', '>');
}
