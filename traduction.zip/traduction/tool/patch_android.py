"""Adds the permissions Traduction needs to the Android manifest created by `flutter create`."""
import re

path = "android/app/src/main/AndroidManifest.xml"
xml = open(path, encoding="utf-8").read()

perms = """    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.RECORD_AUDIO"/>
"""
queries_extra = """        <intent>
            <action android:name="android.speech.RecognitionService"/>
        </intent>
        <intent>
            <action android:name="android.intent.action.TTS_SERVICE"/>
        </intent>
"""

if "RECORD_AUDIO" not in xml:
    xml = re.sub(r"(<manifest[^>]*>\n)", r"\1" + perms, xml, count=1)
if "RecognitionService" not in xml:
    if "<queries>" in xml:
        xml = xml.replace("<queries>\n", "<queries>\n" + queries_extra, 1)
    else:
        xml = xml.replace("</manifest>", "    <queries>\n" + queries_extra + "    </queries>\n</manifest>")
xml = re.sub(r'android:label="[^"]*"', 'android:label="Traduction"', xml, count=1)

open(path, "w", encoding="utf-8").write(xml)
print(xml)
