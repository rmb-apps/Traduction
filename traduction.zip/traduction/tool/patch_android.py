"""Adds the permissions Traduction needs to the Android manifest created by `flutter create`."""
import re

path = "android/app/src/main/AndroidManifest.xml"
xml = open(path, encoding="utf-8").read()

perms = """    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.RECORD_AUDIO"/>
"""
queries_extra = """        <intent>
            <action android:name="android.speech.RecognitionService"/>
        </intent>
        <intent>
            <action android:name="android.intent.action.TTS_SERVICE"/>
        </intent>
"""

if "RECORD_AUDIO" not in xml:
    xml = re.sub(r"(<manifest[^>]*>\n)", r"\1" + perms, xml, count=1)
if "RecognitionService" not in xml:
    if "<queries>" in xml:
        xml = xml.replace("<queries>\n", "<queries>\n" + queries_extra, 1)
    else:
        xml = xml.replace("</manifest>", "    <queries>\n" + queries_extra + "    </queries>\n</manifest>")
xml = re.sub(r'android:label="[^"]*"', 'android:label="Traduction"', xml, count=1)

open(path, "w", encoding="utf-8").write(xml)
print(xml)

# ML Kit text recognition references optional script models (Chinese, Japanese...)
# that we don't ship; tell R8 to ignore them so the release build succeeds.
rules = """-dontwarn com.google.mlkit.vision.text.chinese.**
-dontwarn com.google.mlkit.vision.text.devanagari.**
-dontwarn com.google.mlkit.vision.text.japanese.**
-dontwarn com.google.mlkit.vision.text.korean.**
-keep class com.google.mlkit.** { *; }
-keep class com.google.android.gms.internal.mlkit_vision_text_common.** { *; }
-keep class com.google.android.gms.internal.mlkit_vision_common.** { *; }
-keep class com.google_mlkit_commons.** { *; }
-keep class com.google_mlkit_text_recognition.** { *; }
-keep class com.google_mlkit_translation.** { *; }
-keep class io.flutter.plugins.imagepicker.** { *; }
-keep class com.tundralabs.fluttertts.** { *; }
-keep class io.flutter.plugins.camera.** { *; }
-keep class io.flutter.plugins.camerax.** { *; }
-keep class com.csdcorp.speech_to_text.** { *; }
"""
open("android/app/proguard-rules.pro", "w", encoding="utf-8").write(rules)
print("proguard-rules.pro written")

# Skip the "lintVital" checks on plugins: they can crash on some toolchains
# and are not needed to produce the APK.
import os
for gradle in ("android/build.gradle.kts", "android/build.gradle"):
    if os.path.exists(gradle):
        g = open(gradle, encoding="utf-8").read()
        if "lintVital" not in g:
            g += '\nsubprojects {\n    tasks.matching { it.name.startsWith("lintVital") }.configureEach { enabled = false }\n}\n'
            open(gradle, "w", encoding="utf-8").write(g)
            print("lintVital disabled in", gradle)
        break

# Release signing: use android/key.properties (written by the CI from secrets)
# when it exists; otherwise keep the default debug signing.
app_kts = "android/app/build.gradle.kts"
if os.path.exists("android/key.properties") and os.path.exists(app_kts):
    g = open(app_kts, encoding="utf-8").read()
    if "keystoreProperties" not in g:
        imports = "import java.io.FileInputStream\nimport java.util.Properties\n\n"
        header = (
            "val keystoreProperties = Properties()\n"
            "val keystorePropertiesFile = rootProject.file(\"key.properties\")\n"
            "if (keystorePropertiesFile.exists()) {\n"
            "    keystoreProperties.load(FileInputStream(keystorePropertiesFile))\n"
            "}\n\n"
        )
        signing = (
            "    signingConfigs {\n"
            "        create(\"release\") {\n"
            "            keyAlias = keystoreProperties[\"keyAlias\"] as String\n"
            "            keyPassword = keystoreProperties[\"keyPassword\"] as String\n"
            "            storeFile = file(keystoreProperties[\"storeFile\"] as String)\n"
            "            storePassword = keystoreProperties[\"storePassword\"] as String\n"
            "        }\n"
            "    }\n\n"
            "    buildTypes {"
        )
        # Kotlin DSL: imports first, plugins {} next, then other statements.
        g = imports + g.replace("\nandroid {", "\n" + header + "android {", 1)
        g = g.replace("    buildTypes {", signing, 1)
        g = re.sub(r'signingConfig = signingConfigs\.getByName\("debug"\)',
                   'signingConfig = signingConfigs.getByName("release")', g)
        open(app_kts, "w", encoding="utf-8").write(g)
        print("release signing configured")
